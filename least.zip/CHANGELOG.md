## least.js 2 Changelog
> last change: 16/01/2014 - initial release

## V - 2.0.1 (16/01/2014)
> initial release
