## least.js 2 Changelog
> last change: 16/01/2014 - initial release

## 0.1 (00/00/00)
> initial release
